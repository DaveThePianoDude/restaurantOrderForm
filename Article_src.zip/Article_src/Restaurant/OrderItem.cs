﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Restaurant
{
    public class OrderItem
    {
        public int Id { get; private set; }

        public int Quantity { get; private set; }
    }
}
